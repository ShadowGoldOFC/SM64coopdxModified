-- name: Big Triple Jump
-- description: If you hold x while triple jumping you get launched forward. \n\n You will deal no fall damage if you hit the ground or during the big triple jump.\n\n\n\nMod by GroovyBeardLover
local TRIPLE_JUMP_AVAILABLE = true

function mario_jump(m)
    if TRIPLE_JUMP_AVAILABLE == true then
        if m.action == ACT_TRIPLE_JUMP then
            if (m.controller.buttonDown & X_BUTTON) ~= 0 then
                play_character_sound(m, CHAR_SOUND_HERE_WE_GO)
                m.forwardVel = m.forwardVel + 100
                m.vel.y = m.vel.y + 50
                TRIPLE_JUMP_AVAILABLE = false
                m.particleFlags = PARTICLE_SPARKLES
                play_sound(SOUND_GENERAL_GRAND_STAR_JUMP, m.pos)
            end
        end
    end
end

function fall_damage(m)
    if TRIPLE_JUMP_AVAILABLE == false then
        m.peakHeight = m.pos.y
    end
    if m.action == ACT_WALKING then
        TRIPLE_JUMP_AVAILABLE = true
    end
    if m.action == ACT_JUMP then
        TRIPLE_JUMP_AVAILABLE = true
    end
end

hook_event(HOOK_MARIO_UPDATE, fall_damage)
hook_event(HOOK_MARIO_UPDATE, mario_jump)